#NAME: Nikhil Malhotra
#EMAIL: nikhilmalhotra@g.ucla.edu
#ID: 505103892

###
./lab2_list --sync=m --iterations=1000 --thread=1
./lab2_list --sync=s --iterations=1000 --thread=1
./lab2_list --sync=m --iterations=1000 --thread=2
./lab2_list --sync=s --iterations=1000 --thread=2
./lab2_list --sync=m --iterations=1000 --thread=4
./lab2_list --sync=s --iterations=1000 --thread=4
./lab2_list --sync=m --iterations=1000 --thread=8
./lab2_list --sync=s --iterations=1000 --thread=8
./lab2_list --sync=m --iterations=1000 --thread=12
./lab2_list --sync=s --iterations=1000 --thread=12
./lab2_list --sync=m --iterations=1000 --thread=16
./lab2_list --sync=s --iterations=1000 --thread=16
./lab2_list --sync=m --iterations=1000 --thread=24
./lab2_list --sync=s --iterations=1000 --thread=24

###
./lab2_list --yield=id --lists=4 --iterations=1 --thread=1
./lab2_list --yield=id --lists=4 --iterations=1 --thread=4
./lab2_list --yield=id --lists=4 --iterations=1 --thread=8
./lab2_list --yield=id --lists=4 --iterations=1 --thread=12
./lab2_list --yield=id --lists=4 --iterations=1 --thread=16
./lab2_list --yield=id --lists=4 --iterations=2 --thread=1
./lab2_list --yield=id --lists=4 --iterations=2 --thread=4
./lab2_list --yield=id --lists=4 --iterations=2 --thread=8
./lab2_list --yield=id --lists=4 --iterations=2 --thread=12
./lab2_list --yield=id --lists=4 --iterations=2 --thread=16
./lab2_list --yield=id --lists=4 --iterations=4 --thread=1
./lab2_list --yield=id --lists=4 --iterations=4 --thread=4
./lab2_list --yield=id --lists=4 --iterations=4 --thread=8
./lab2_list --yield=id --lists=4 --iterations=4 --thread=12
./lab2_list --yield=id --lists=4 --iterations=4 --thread=16
./lab2_list --yield=id --lists=4 --iterations=8 --thread=1
./lab2_list --yield=id --lists=4 --iterations=8 --thread=4
./lab2_list --yield=id --lists=4 --iterations=8 --thread=8
./lab2_list --yield=id --lists=4 --iterations=8 --thread=12
./lab2_list --yield=id --lists=4 --iterations=8 --thread=16
./lab2_list --yield=id --lists=4 --iterations=16 --thread=1
./lab2_list --yield=id --lists=4 --iterations=16 --thread=4
./lab2_list --yield=id --lists=4 --iterations=16 --thread=8
./lab2_list --yield=id --lists=4 --iterations=16 --thread=12
./lab2_list --yield=id --lists=4 --iterations=16 --thread=16

###
./lab2_list --yield=id --sync=m --lists=4 --iterations=10 --thread=1
./lab2_list --yield=id --sync=s --lists=4 --iterations=10 --thread=1
./lab2_list --yield=id --sync=m --lists=4 --iterations=10 --thread=4
./lab2_list --yield=id --sync=s --lists=4 --iterations=10 --thread=4
./lab2_list --yield=id --sync=m --lists=4 --iterations=10 --thread=8
./lab2_list --yield=id --sync=s --lists=4 --iterations=10 --thread=8
./lab2_list --yield=id --sync=m --lists=4 --iterations=10 --thread=12
./lab2_list --yield=id --sync=s --lists=4 --iterations=10 --thread=12
./lab2_list --yield=id --sync=m --lists=4 --iterations=10 --thread=16
./lab2_list --yield=id --sync=s --lists=4 --iterations=10 --thread=16
./lab2_list --yield=id --sync=m --lists=4 --iterations=20 --thread=1
./lab2_list --yield=id --sync=s --lists=4 --iterations=20 --thread=1
./lab2_list --yield=id --sync=m --lists=4 --iterations=20 --thread=4
./lab2_list --yield=id --sync=s --lists=4 --iterations=20 --thread=4
./lab2_list --yield=id --sync=m --lists=4 --iterations=20 --thread=8
./lab2_list --yield=id --sync=s --lists=4 --iterations=20 --thread=8
./lab2_list --yield=id --sync=m --lists=4 --iterations=20 --thread=12
./lab2_list --yield=id --sync=s --lists=4 --iterations=20 --thread=12
./lab2_list --yield=id --sync=m --lists=4 --iterations=20 --thread=16
./lab2_list --yield=id --sync=s --lists=4 --iterations=20 --thread=16
./lab2_list --yield=id --sync=m --lists=4 --iterations=40 --thread=1
./lab2_list --yield=id --sync=s --lists=4 --iterations=40 --thread=1
./lab2_list --yield=id --sync=m --lists=4 --iterations=40 --thread=4
./lab2_list --yield=id --sync=s --lists=4 --iterations=40 --thread=4
./lab2_list --yield=id --sync=m --lists=4 --iterations=40 --thread=8
./lab2_list --yield=id --sync=s --lists=4 --iterations=40 --thread=8
./lab2_list --yield=id --sync=m --lists=4 --iterations=40 --thread=12
./lab2_list --yield=id --sync=s --lists=4 --iterations=40 --thread=12
./lab2_list --yield=id --sync=m --lists=4 --iterations=40 --thread=16
./lab2_list --yield=id --sync=s --lists=4 --iterations=40 --thread=16
./lab2_list --yield=id --sync=m --lists=4 --iterations=80 --thread=1
./lab2_list --yield=id --sync=s --lists=4 --iterations=80 --thread=1
./lab2_list --yield=id --sync=m --lists=4 --iterations=80 --thread=4
./lab2_list --yield=id --sync=s --lists=4 --iterations=80 --thread=4
./lab2_list --yield=id --sync=m --lists=4 --iterations=80 --thread=8
./lab2_list --yield=id --sync=s --lists=4 --iterations=80 --thread=8
./lab2_list --yield=id --sync=m --lists=4 --iterations=80 --thread=12
./lab2_list --yield=id --sync=s --lists=4 --iterations=80 --thread=12
./lab2_list --yield=id --sync=m --lists=4 --iterations=80 --thread=16
./lab2_list --yield=id --sync=s --lists=4 --iterations=80 --thread=16

###
./lab2_list --sync=m --lists=1 --iterations=1000 --thread=1
./lab2_list --sync=s --lists=1 --iterations=1000 --thread=1
./lab2_list --sync=m --lists=1 --iterations=1000 --thread=2
./lab2_list --sync=s --lists=1 --iterations=1000 --thread=2
./lab2_list --sync=m --lists=1 --iterations=1000 --thread=4
./lab2_list --sync=s --lists=1 --iterations=1000 --thread=4
./lab2_list --sync=m --lists=1 --iterations=1000 --thread=8
./lab2_list --sync=s --lists=1 --iterations=1000 --thread=8
./lab2_list --sync=m --lists=1 --iterations=1000 --thread=12
./lab2_list --sync=s --lists=1 --iterations=1000 --thread=12
./lab2_list --sync=m --lists=4 --iterations=1000 --thread=1
./lab2_list --sync=s --lists=4 --iterations=1000 --thread=1
./lab2_list --sync=m --lists=4 --iterations=1000 --thread=2
./lab2_list --sync=s --lists=4 --iterations=1000 --thread=2
./lab2_list --sync=m --lists=4 --iterations=1000 --thread=4
./lab2_list --sync=s --lists=4 --iterations=1000 --thread=4
./lab2_list --sync=m --lists=4 --iterations=1000 --thread=8
./lab2_list --sync=s --lists=4 --iterations=1000 --thread=8
./lab2_list --sync=m --lists=4 --iterations=1000 --thread=12
./lab2_list --sync=s --lists=4 --iterations=1000 --thread=12
./lab2_list --sync=m --lists=8 --iterations=1000 --thread=1
./lab2_list --sync=s --lists=8 --iterations=1000 --thread=1
./lab2_list --sync=m --lists=8 --iterations=1000 --thread=2
./lab2_list --sync=s --lists=8 --iterations=1000 --thread=2
./lab2_list --sync=m --lists=8 --iterations=1000 --thread=4
./lab2_list --sync=s --lists=8 --iterations=1000 --thread=4
./lab2_list --sync=m --lists=8 --iterations=1000 --thread=8
./lab2_list --sync=s --lists=8 --iterations=1000 --thread=8
./lab2_list --sync=m --lists=8 --iterations=1000 --thread=12
./lab2_list --sync=s --lists=8 --iterations=1000 --thread=12
./lab2_list --sync=m --lists=16 --iterations=1000 --thread=1
./lab2_list --sync=s --lists=16 --iterations=1000 --thread=1
./lab2_list --sync=m --lists=16 --iterations=1000 --thread=2
./lab2_list --sync=s --lists=16 --iterations=1000 --thread=2
./lab2_list --sync=m --lists=16 --iterations=1000 --thread=4
./lab2_list --sync=s --lists=16 --iterations=1000 --thread=4
./lab2_list --sync=m --lists=16 --iterations=1000 --thread=8
./lab2_list --sync=s --lists=16 --iterations=1000 --thread=8
./lab2_list --sync=m --lists=16 --iterations=1000 --thread=12
./lab2_list --sync=s --lists=16 --iterations=1000 --thread=12
