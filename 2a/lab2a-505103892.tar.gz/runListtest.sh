#NAME: Nikhil Malhotra
#EMAIL: nikhilmalhotra@g.ucla.edu
#ID: 505103892

###
./lab2_list --iterations=10 --thread=1
./lab2_list --iterations=100 --thread=1
./lab2_list --iterations=1000 --thread=1
./lab2_list --iterations=10000 --thread=1
./lab2_list --iterations=20000 --thread=1

###
./lab2_list --iterations=1 --thread=2
./lab2_list --iterations=1 --thread=4
./lab2_list --iterations=1 --thread=8
./lab2_list --iterations=1 --thread=12
./lab2_list --iterations=10 --thread=2
./lab2_list --iterations=10 --thread=4
./lab2_list --iterations=10 --thread=8
./lab2_list --iterations=10 --thread=12
./lab2_list --iterations=100 --thread=2
./lab2_list --iterations=100 --thread=4
./lab2_list --iterations=100 --thread=8
./lab2_list --iterations=100 --thread=12
./lab2_list --iterations=1000 --thread=2
./lab2_list --iterations=1000 --thread=4
./lab2_list --iterations=1000 --thread=8
./lab2_list --iterations=1000 --thread=12

###
./lab2_list --yield=i --iterations=1 --thread=2
./lab2_list --yield=d --iterations=1 --thread=2
./lab2_list --yield=il --iterations=1 --thread=2
./lab2_list --yield=dl --iterations=1 --thread=2
./lab2_list --yield=i --iterations=1 --thread=4
./lab2_list --yield=d --iterations=1 --thread=4
./lab2_list --yield=il --iterations=1 --thread=4
./lab2_list --yield=dl --iterations=1 --thread=4
./lab2_list --yield=i --iterations=1 --thread=8
./lab2_list --yield=d --iterations=1 --thread=8
./lab2_list --yield=il --iterations=1 --thread=8
./lab2_list --yield=dl --iterations=1 --thread=8
./lab2_list --yield=i --iterations=1 --thread=12
./lab2_list --yield=d --iterations=1 --thread=12
./lab2_list --yield=il --iterations=1 --thread=12
./lab2_list --yield=dl --iterations=1 --thread=12
./lab2_list --yield=i --iterations=2 --thread=2
./lab2_list --yield=d --iterations=2 --thread=2
./lab2_list --yield=il --iterations=2 --thread=2
./lab2_list --yield=dl --iterations=2 --thread=2
./lab2_list --yield=i --iterations=2 --thread=4
./lab2_list --yield=d --iterations=2 --thread=4
./lab2_list --yield=il --iterations=2 --thread=4
./lab2_list --yield=dl --iterations=2 --thread=4
./lab2_list --yield=i --iterations=2 --thread=8
./lab2_list --yield=d --iterations=2 --thread=8
./lab2_list --yield=il --iterations=2 --thread=8
./lab2_list --yield=dl --iterations=2 --thread=8
./lab2_list --yield=i --iterations=2 --thread=12
./lab2_list --yield=d --iterations=2 --thread=12
./lab2_list --yield=il --iterations=2 --thread=12
./lab2_list --yield=dl --iterations=2 --thread=12
./lab2_list --yield=i --iterations=4 --thread=2
./lab2_list --yield=d --iterations=4 --thread=2
./lab2_list --yield=il --iterations=4 --thread=2
./lab2_list --yield=dl --iterations=4 --thread=2
./lab2_list --yield=i --iterations=4 --thread=4
./lab2_list --yield=d --iterations=4 --thread=4
./lab2_list --yield=il --iterations=4 --thread=4
./lab2_list --yield=dl --iterations=4 --thread=4
./lab2_list --yield=i --iterations=4 --thread=8
./lab2_list --yield=d --iterations=4 --thread=8
./lab2_list --yield=il --iterations=4 --thread=8
./lab2_list --yield=dl --iterations=4 --thread=8
./lab2_list --yield=i --iterations=4 --thread=12
./lab2_list --yield=d --iterations=4 --thread=12
./lab2_list --yield=il --iterations=4 --thread=12
./lab2_list --yield=dl --iterations=4 --thread=12
./lab2_list --yield=i --iterations=8 --thread=2
./lab2_list --yield=d --iterations=8 --thread=2
./lab2_list --yield=il --iterations=8 --thread=2
./lab2_list --yield=dl --iterations=8 --thread=2
./lab2_list --yield=i --iterations=8 --thread=4
./lab2_list --yield=d --iterations=8 --thread=4
./lab2_list --yield=il --iterations=8 --thread=4
./lab2_list --yield=dl --iterations=8 --thread=4
./lab2_list --yield=i --iterations=8 --thread=8
./lab2_list --yield=d --iterations=8 --thread=8
./lab2_list --yield=il --iterations=8 --thread=8
./lab2_list --yield=dl --iterations=8 --thread=8
./lab2_list --yield=i --iterations=8 --thread=12
./lab2_list --yield=d --iterations=8 --thread=12
./lab2_list --yield=il --iterations=8 --thread=12
./lab2_list --yield=dl --iterations=8 --thread=12
./lab2_list --yield=i --iterations=16 --thread=2
./lab2_list --yield=d --iterations=16 --thread=2
./lab2_list --yield=il --iterations=16 --thread=2
./lab2_list --yield=dl --iterations=16 --thread=2
./lab2_list --yield=i --iterations=16 --thread=4
./lab2_list --yield=d --iterations=16 --thread=4
./lab2_list --yield=il --iterations=16 --thread=4
./lab2_list --yield=dl --iterations=16 --thread=4
./lab2_list --yield=i --iterations=16 --thread=8
./lab2_list --yield=d --iterations=16 --thread=8
./lab2_list --yield=il --iterations=16 --thread=8
./lab2_list --yield=dl --iterations=16 --thread=8
./lab2_list --yield=i --iterations=16 --thread=12
./lab2_list --yield=d --iterations=16 --thread=12
./lab2_list --yield=il --iterations=16 --thread=12
./lab2_list --yield=dl --iterations=16 --thread=12
./lab2_list --yield=i --iterations=32 --thread=2
./lab2_list --yield=d --iterations=32 --thread=2
./lab2_list --yield=il --iterations=32 --thread=2
./lab2_list --yield=dl --iterations=32 --thread=2
./lab2_list --yield=i --iterations=32 --thread=4
./lab2_list --yield=d --iterations=32 --thread=4
./lab2_list --yield=il --iterations=32 --thread=4
./lab2_list --yield=dl --iterations=32 --thread=4
./lab2_list --yield=i --iterations=32 --thread=8
./lab2_list --yield=d --iterations=32 --thread=8
./lab2_list --yield=il --iterations=32 --thread=8
./lab2_list --yield=dl --iterations=32 --thread=8
./lab2_list --yield=i --iterations=32 --thread=12
./lab2_list --yield=d --iterations=32 --thread=12
./lab2_list --yield=il --iterations=32 --thread=12
./lab2_list --yield=dl --iterations=32 --thread=12

###
./lab2_list --sync=m --yield=i --iterations=1 --thread=2
./lab2_list --sync=m --yield=d --iterations=1 --thread=2
./lab2_list --sync=m --yield=il --iterations=1 --thread=2
./lab2_list --sync=m --yield=dl --iterations=1 --thread=2
./lab2_list --sync=m --yield=i --iterations=1 --thread=4
./lab2_list --sync=m --yield=d --iterations=1 --thread=4
./lab2_list --sync=m --yield=il --iterations=1 --thread=4
./lab2_list --sync=m --yield=dl --iterations=1 --thread=4
./lab2_list --sync=m --yield=i --iterations=1 --thread=8
./lab2_list --sync=m --yield=d --iterations=1 --thread=8
./lab2_list --sync=m --yield=il --iterations=1 --thread=8
./lab2_list --sync=m --yield=dl --iterations=1 --thread=8
./lab2_list --sync=m --yield=i --iterations=1 --thread=12
./lab2_list --sync=m --yield=d --iterations=1 --thread=12
./lab2_list --sync=m --yield=il --iterations=1 --thread=12
./lab2_list --sync=m --yield=dl --iterations=1 --thread=12
./lab2_list --sync=m --yield=i --iterations=2 --thread=2
./lab2_list --sync=m --yield=d --iterations=2 --thread=2
./lab2_list --sync=m --yield=il --iterations=2 --thread=2
./lab2_list --sync=m --yield=dl --iterations=2 --thread=2
./lab2_list --sync=m --yield=i --iterations=2 --thread=4
./lab2_list --sync=m --yield=d --iterations=2 --thread=4
./lab2_list --sync=m --yield=il --iterations=2 --thread=4
./lab2_list --sync=m --yield=dl --iterations=2 --thread=4
./lab2_list --sync=m --yield=i --iterations=2 --thread=8
./lab2_list --sync=m --yield=d --iterations=2 --thread=8
./lab2_list --sync=m --yield=il --iterations=2 --thread=8
./lab2_list --sync=m --yield=dl --iterations=2 --thread=8
./lab2_list --sync=m --yield=i --iterations=2 --thread=12
./lab2_list --sync=m --yield=d --iterations=2 --thread=12
./lab2_list --sync=m --yield=il --iterations=2 --thread=12
./lab2_list --sync=m --yield=dl --iterations=2 --thread=12
./lab2_list --sync=m --yield=i --iterations=4 --thread=2
./lab2_list --sync=m --yield=d --iterations=4 --thread=2
./lab2_list --sync=m --yield=il --iterations=4 --thread=2
./lab2_list --sync=m --yield=dl --iterations=4 --thread=2
./lab2_list --sync=m --yield=i --iterations=4 --thread=4
./lab2_list --sync=m --yield=d --iterations=4 --thread=4
./lab2_list --sync=m --yield=il --iterations=4 --thread=4
./lab2_list --sync=m --yield=dl --iterations=4 --thread=4
./lab2_list --sync=m --yield=i --iterations=4 --thread=8
./lab2_list --sync=m --yield=d --iterations=4 --thread=8
./lab2_list --sync=m --yield=il --iterations=4 --thread=8
./lab2_list --sync=m --yield=dl --iterations=4 --thread=8
./lab2_list --sync=m --yield=i --iterations=4 --thread=12
./lab2_list --sync=m --yield=d --iterations=4 --thread=12
./lab2_list --sync=m --yield=il --iterations=4 --thread=12
./lab2_list --sync=m --yield=dl --iterations=4 --thread=12
./lab2_list --sync=m --yield=i --iterations=8 --thread=2
./lab2_list --sync=m --yield=d --iterations=8 --thread=2
./lab2_list --sync=m --yield=il --iterations=8 --thread=2
./lab2_list --sync=m --yield=dl --iterations=8 --thread=2
./lab2_list --sync=m --yield=i --iterations=8 --thread=4
./lab2_list --sync=m --yield=d --iterations=8 --thread=4
./lab2_list --sync=m --yield=il --iterations=8 --thread=4
./lab2_list --sync=m --yield=dl --iterations=8 --thread=4
./lab2_list --sync=m --yield=i --iterations=8 --thread=8
./lab2_list --sync=m --yield=d --iterations=8 --thread=8
./lab2_list --sync=m --yield=il --iterations=8 --thread=8
./lab2_list --sync=m --yield=dl --iterations=8 --thread=8
./lab2_list --sync=m --yield=i --iterations=8 --thread=12
./lab2_list --sync=m --yield=d --iterations=8 --thread=12
./lab2_list --sync=m --yield=il --iterations=8 --thread=12
./lab2_list --sync=m --yield=dl --iterations=8 --thread=12
./lab2_list --sync=m --yield=i --iterations=16 --thread=2
./lab2_list --sync=m --yield=d --iterations=16 --thread=2
./lab2_list --sync=m --yield=il --iterations=16 --thread=2
./lab2_list --sync=m --yield=dl --iterations=16 --thread=2
./lab2_list --sync=m --yield=i --iterations=16 --thread=4
./lab2_list --sync=m --yield=d --iterations=16 --thread=4
./lab2_list --sync=m --yield=il --iterations=16 --thread=4
./lab2_list --sync=m --yield=dl --iterations=16 --thread=4
./lab2_list --sync=m --yield=i --iterations=16 --thread=8
./lab2_list --sync=m --yield=d --iterations=16 --thread=8
./lab2_list --sync=m --yield=il --iterations=16 --thread=8
./lab2_list --sync=m --yield=dl --iterations=16 --thread=8
./lab2_list --sync=m --yield=i --iterations=16 --thread=12
./lab2_list --sync=m --yield=d --iterations=16 --thread=12
./lab2_list --sync=m --yield=il --iterations=16 --thread=12
./lab2_list --sync=m --yield=dl --iterations=16 --thread=12
./lab2_list --sync=m --yield=i --iterations=32 --thread=2
./lab2_list --sync=m --yield=d --iterations=32 --thread=2
./lab2_list --sync=m --yield=il --iterations=32 --thread=2
./lab2_list --sync=m --yield=dl --iterations=32 --thread=2
./lab2_list --sync=m --yield=i --iterations=32 --thread=4
./lab2_list --sync=m --yield=d --iterations=32 --thread=4
./lab2_list --sync=m --yield=il --iterations=32 --thread=4
./lab2_list --sync=m --yield=dl --iterations=32 --thread=4
./lab2_list --sync=m --yield=i --iterations=32 --thread=8
./lab2_list --sync=m --yield=d --iterations=32 --thread=8
./lab2_list --sync=m --yield=il --iterations=32 --thread=8
./lab2_list --sync=m --yield=dl --iterations=32 --thread=8
./lab2_list --sync=m --yield=i --iterations=32 --thread=12
./lab2_list --sync=m --yield=d --iterations=32 --thread=12
./lab2_list --sync=m --yield=il --iterations=32 --thread=12
./lab2_list --sync=m --yield=dl --iterations=32 --thread=12
./lab2_list --sync=s --yield=i --iterations=1 --thread=2
./lab2_list --sync=s --yield=d --iterations=1 --thread=2
./lab2_list --sync=s --yield=il --iterations=1 --thread=2
./lab2_list --sync=s --yield=dl --iterations=1 --thread=2
./lab2_list --sync=s --yield=i --iterations=1 --thread=4
./lab2_list --sync=s --yield=d --iterations=1 --thread=4
./lab2_list --sync=s --yield=il --iterations=1 --thread=4
./lab2_list --sync=s --yield=dl --iterations=1 --thread=4
./lab2_list --sync=s --yield=i --iterations=1 --thread=8
./lab2_list --sync=s --yield=d --iterations=1 --thread=8
./lab2_list --sync=s --yield=il --iterations=1 --thread=8
./lab2_list --sync=s --yield=dl --iterations=1 --thread=8
./lab2_list --sync=s --yield=i --iterations=1 --thread=12
./lab2_list --sync=s --yield=d --iterations=1 --thread=12
./lab2_list --sync=s --yield=il --iterations=1 --thread=12
./lab2_list --sync=s --yield=dl --iterations=1 --thread=12
./lab2_list --sync=s --yield=i --iterations=2 --thread=2
./lab2_list --sync=s --yield=d --iterations=2 --thread=2
./lab2_list --sync=s --yield=il --iterations=2 --thread=2
./lab2_list --sync=s --yield=dl --iterations=2 --thread=2
./lab2_list --sync=s --yield=i --iterations=2 --thread=4
./lab2_list --sync=s --yield=d --iterations=2 --thread=4
./lab2_list --sync=s --yield=il --iterations=2 --thread=4
./lab2_list --sync=s --yield=dl --iterations=2 --thread=4
./lab2_list --sync=s --yield=i --iterations=2 --thread=8
./lab2_list --sync=s --yield=d --iterations=2 --thread=8
./lab2_list --sync=s --yield=il --iterations=2 --thread=8
./lab2_list --sync=s --yield=dl --iterations=2 --thread=8
./lab2_list --sync=s --yield=i --iterations=2 --thread=12
./lab2_list --sync=s --yield=d --iterations=2 --thread=12
./lab2_list --sync=s --yield=il --iterations=2 --thread=12
./lab2_list --sync=s --yield=dl --iterations=2 --thread=12
./lab2_list --sync=s --yield=i --iterations=4 --thread=2
./lab2_list --sync=s --yield=d --iterations=4 --thread=2
./lab2_list --sync=s --yield=il --iterations=4 --thread=2
./lab2_list --sync=s --yield=dl --iterations=4 --thread=2
./lab2_list --sync=s --yield=i --iterations=4 --thread=4
./lab2_list --sync=s --yield=d --iterations=4 --thread=4
./lab2_list --sync=s --yield=il --iterations=4 --thread=4
./lab2_list --sync=s --yield=dl --iterations=4 --thread=4
./lab2_list --sync=s --yield=i --iterations=4 --thread=8
./lab2_list --sync=s --yield=d --iterations=4 --thread=8
./lab2_list --sync=s --yield=il --iterations=4 --thread=8
./lab2_list --sync=s --yield=dl --iterations=4 --thread=8
./lab2_list --sync=s --yield=i --iterations=4 --thread=12
./lab2_list --sync=s --yield=d --iterations=4 --thread=12
./lab2_list --sync=s --yield=il --iterations=4 --thread=12
./lab2_list --sync=s --yield=dl --iterations=4 --thread=12
./lab2_list --sync=s --yield=i --iterations=8 --thread=2
./lab2_list --sync=s --yield=d --iterations=8 --thread=2
./lab2_list --sync=s --yield=il --iterations=8 --thread=2
./lab2_list --sync=s --yield=dl --iterations=8 --thread=2
./lab2_list --sync=s --yield=i --iterations=8 --thread=4
./lab2_list --sync=s --yield=d --iterations=8 --thread=4
./lab2_list --sync=s --yield=il --iterations=8 --thread=4
./lab2_list --sync=s --yield=dl --iterations=8 --thread=4
./lab2_list --sync=s --yield=i --iterations=8 --thread=8
./lab2_list --sync=s --yield=d --iterations=8 --thread=8
./lab2_list --sync=s --yield=il --iterations=8 --thread=8
./lab2_list --sync=s --yield=dl --iterations=8 --thread=8
./lab2_list --sync=s --yield=i --iterations=8 --thread=12
./lab2_list --sync=s --yield=d --iterations=8 --thread=12
./lab2_list --sync=s --yield=il --iterations=8 --thread=12
./lab2_list --sync=s --yield=dl --iterations=8 --thread=12
./lab2_list --sync=s --yield=i --iterations=16 --thread=2
./lab2_list --sync=s --yield=d --iterations=16 --thread=2
./lab2_list --sync=s --yield=il --iterations=16 --thread=2
./lab2_list --sync=s --yield=dl --iterations=16 --thread=2
./lab2_list --sync=s --yield=i --iterations=16 --thread=4
./lab2_list --sync=s --yield=d --iterations=16 --thread=4
./lab2_list --sync=s --yield=il --iterations=16 --thread=4
./lab2_list --sync=s --yield=dl --iterations=16 --thread=4
./lab2_list --sync=s --yield=i --iterations=16 --thread=8
./lab2_list --sync=s --yield=d --iterations=16 --thread=8
./lab2_list --sync=s --yield=il --iterations=16 --thread=8
./lab2_list --sync=s --yield=dl --iterations=16 --thread=8
./lab2_list --sync=s --yield=i --iterations=16 --thread=12
./lab2_list --sync=s --yield=d --iterations=16 --thread=12
./lab2_list --sync=s --yield=il --iterations=16 --thread=12
./lab2_list --sync=s --yield=dl --iterations=16 --thread=12
./lab2_list --sync=s --yield=i --iterations=32 --thread=2
./lab2_list --sync=s --yield=d --iterations=32 --thread=2
./lab2_list --sync=s --yield=il --iterations=32 --thread=2
./lab2_list --sync=s --yield=dl --iterations=32 --thread=2
./lab2_list --sync=s --yield=i --iterations=32 --thread=4
./lab2_list --sync=s --yield=d --iterations=32 --thread=4
./lab2_list --sync=s --yield=il --iterations=32 --thread=4
./lab2_list --sync=s --yield=dl --iterations=32 --thread=4
./lab2_list --sync=s --yield=i --iterations=32 --thread=8
./lab2_list --sync=s --yield=d --iterations=32 --thread=8
./lab2_list --sync=s --yield=il --iterations=32 --thread=8
./lab2_list --sync=s --yield=dl --iterations=32 --thread=8
./lab2_list --sync=s --yield=i --iterations=32 --thread=12
./lab2_list --sync=s --yield=d --iterations=32 --thread=12
./lab2_list --sync=s --yield=il --iterations=32 --thread=12
./lab2_list --sync=s --yield=dl --iterations=32 --thread=12

###
./lab2_list --sync=m --iterations=1000 --thread=1
./lab2_list --sync=s --iterations=1000 --thread=1
./lab2_list --sync=m --iterations=1000 --thread=2
./lab2_list --sync=s --iterations=1000 --thread=2
./lab2_list --sync=m --iterations=1000 --thread=4
./lab2_list --sync=s --iterations=1000 --thread=4
./lab2_list --sync=m --iterations=1000 --thread=8
./lab2_list --sync=s --iterations=1000 --thread=8
./lab2_list --sync=m --iterations=1000 --thread=12
./lab2_list --sync=s --iterations=1000 --thread=12
./lab2_list --sync=m --iterations=1000 --thread=16
./lab2_list --sync=s --iterations=1000 --thread=16
./lab2_list --sync=m --iterations=1000 --thread=24
./lab2_list --sync=s --iterations=1000 --thread=24
