#NAME: Nikhil Malhotra
#EMAIL: nikhilmalhotra@g.ucla.edu
#ID: 505103892

###
./lab2_add --thread=10 --iterations=100
./lab2_add --thread=10 --iterations=1000
./lab2_add --thread=10 --iterations=10000
./lab2_add --thread=10 --iterations=100000

###
./lab2_add --thread=2 --iterations=10 --yield
./lab2_add --thread=2 --iterations=20 --yield
./lab2_add --thread=2 --iterations=40 --yield
./lab2_add --thread=2 --iterations=80 --yield
./lab2_add --thread=2 --iterations=100 --yield
./lab2_add --thread=2 --iterations=1000 --yield
./lab2_add --thread=2 --iterations=10000 --yield
./lab2_add --thread=2 --iterations=100000 --yield
./lab2_add --thread=4 --iterations=10 --yield
./lab2_add --thread=4 --iterations=20 --yield
./lab2_add --thread=4 --iterations=40 --yield
./lab2_add --thread=4 --iterations=80 --yield
./lab2_add --thread=4 --iterations=100 --yield
./lab2_add --thread=4 --iterations=1000 --yield
./lab2_add --thread=4 --iterations=10000 --yield
./lab2_add --thread=4 --iterations=100000 --yield
./lab2_add --thread=8 --iterations=10 --yield
./lab2_add --thread=8 --iterations=20 --yield
./lab2_add --thread=8 --iterations=40 --yield
./lab2_add --thread=8 --iterations=80 --yield
./lab2_add --thread=8 --iterations=100 --yield
./lab2_add --thread=8 --iterations=1000 --yield
./lab2_add --thread=8 --iterations=10000 --yield
./lab2_add --thread=8 --iterations=100000 --yield
./lab2_add --thread=12 --iterations=10 --yield
./lab2_add --thread=12 --iterations=20 --yield
./lab2_add --thread=12 --iterations=40 --yield
./lab2_add --thread=12 --iterations=80 --yield
./lab2_add --thread=12 --iterations=100 --yield
./lab2_add --thread=12 --iterations=1000 --yield
./lab2_add --thread=12 --iterations=10000 --yield
./lab2_add --thread=12 --iterations=100000 --yield

###
./lab2_add --thread=2 --iterations=100
./lab2_add --thread=2 --iterations=1000
./lab2_add --thread=2 --iterations=10000
./lab2_add --thread=2 --iterations=100000
./lab2_add --thread=8 --iterations=100
./lab2_add --thread=8 --iterations=1000
./lab2_add --thread=8 --iterations=10000
./lab2_add --thread=8 --iterations=100000

###
./lab2_add --thread=2 --iterations=10000 --sync=m --yield
./lab2_add --thread=4 --iterations=10000 --sync=m --yield
./lab2_add --thread=8 --iterations=10000 --sync=m --yield
./lab2_add --thread=12 --iterations=10000 --sync=m --yield

###
./lab2_add --thread=2 --iterations=10000 --sync=c --yield
./lab2_add --thread=4 --iterations=10000 --sync=c --yield
./lab2_add --thread=8 --iterations=10000 --sync=c --yield
./lab2_add --thread=12 --iterations=10000 --sync=c --yield

###
./lab2_add --thread=2 --iterations=1000 --sync=s --yield
./lab2_add --thread=4 --iterations=1000 --sync=s --yield
./lab2_add --thread=8 --iterations=1000 --sync=s --yield
./lab2_add --thread=12 --iterations=1000 --sync=s --yield

###
./lab2_add --thread=1 --iterations=10000 --sync=m
./lab2_add --thread=2 --iterations=10000 --sync=m
./lab2_add --thread=4 --iterations=10000 --sync=m
./lab2_add --thread=8 --iterations=10000 --sync=m
./lab2_add --thread=12 --iterations=10000 --sync=m

###
./lab2_add --thread=1 --iterations=10000 --sync=s
./lab2_add --thread=2 --iterations=10000 --sync=s
./lab2_add --thread=4 --iterations=10000 --sync=s
./lab2_add --thread=8 --iterations=10000 --sync=s
./lab2_add --thread=12 --iterations=10000 --sync=s

###
./lab2_add --thread=1 --iterations=10000 --sync=c
./lab2_add --thread=2 --iterations=10000 --sync=c
./lab2_add --thread=4 --iterations=10000 --sync=c
./lab2_add --thread=8 --iterations=10000 --sync=c
./lab2_add --thread=12 --iterations=10000 --sync=c

###
./lab2_add --thread=1 --iterations=10000
./lab2_add --thread=2 --iterations=10000
./lab2_add --thread=4 --iterations=10000
./lab2_add --thread=8 --iterations=10000
./lab2_add --thread=12 --iterations=10000

###
./lab2_add --thread=1 --iterations=10
./lab2_add --thread=1 --iterations=100
./lab2_add --thread=1 --iterations=1000
./lab2_add --thread=1 --iterations=10000
